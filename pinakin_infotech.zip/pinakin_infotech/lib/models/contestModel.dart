class ContestModel {
  String name,
      entryText,
      winsText,
      modeText,
      availableText,
      endsText,
      button1Text,
      button2Text;

  ContestModel(
      {required this.name,
      required this.entryText,
      required this.winsText,
      required this.modeText,
      required this.availableText,
      required this.endsText,
      required this.button1Text,
      required this.button2Text});
}
