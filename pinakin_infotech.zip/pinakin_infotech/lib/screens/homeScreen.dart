// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';
import 'package:pinakin_infotech/screens/contestsScreen.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int currentIndex = 2;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const Drawer(),
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text('HOMEPAGE'),
        titleTextStyle: const TextStyle(
          color: Colors.red,
          fontSize: 18,
        ),
        leading: const Icon(
          Icons.menu,
          color: Colors.red,
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(
              Icons.search,
              color: Colors.red,
            ),
          ),
          IconButton(
            onPressed: () {},
            icon: const Icon(
              Icons.notifications_none,
              color: Colors.red,
            ),
          ),
        ],
      ),
      body: IndexedStack(
        index: currentIndex,
        children: [
          Container(),
          Container(),
          ContestScreen(),
          Container(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        onTap: (index) {
          setState(() {
            currentIndex = index;
          });
        },
        currentIndex: currentIndex,
        selectedItemColor: Colors.red,
        unselectedItemColor: Colors.black,
        showUnselectedLabels: true,
        items: [
          BottomNavigationBarItem(
            icon: Icon(
              Icons.menu_book_rounded,
              color: Colors.red,
            ),
            label: 'SPORTSBOOK',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.description,
              color: Colors.red,
            ),
            label: 'CUSTOM',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.card_giftcard,
              color: Colors.red,
            ),
            label: 'CONTESTS',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.format_list_numbered,
              color: Colors.red,
            ),
            label: 'ALL WAGERS',
          ),
        ],
      ),
    );
  }
}
