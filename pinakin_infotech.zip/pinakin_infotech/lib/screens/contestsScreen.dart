// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, must_be_immutable

import 'package:flutter/material.dart';
import 'package:pinakin_infotech/components/contestCard.dart';
import 'package:pinakin_infotech/models/contestModel.dart';

class ContestScreen extends StatelessWidget {
  ContestScreen({Key? key}) : super(key: key);

  List<ContestModel> contests = [
    ContestModel(
      name: 'Champions League Semi Finals',
      entryText: 'Entry 2 of 3',
      winsText: 'Highest Bankroll Wins',
      modeText: 'Free-To-Play',
      availableText: 'Available \$50,000',
      endsText: 'Ends 4/16',
      button1Text: 'Make Pick(s)',
      button2Text: 'View/Edit Picks',
    ),
    ContestModel(
      name: 'Hollywood Contest',
      entryText: 'Entry 1 of 3',
      winsText: 'Most Correct Answers Wins',
      modeText: 'Private',
      availableText: '12 of 12 Picks Made',
      endsText: 'Ends 4/16',
      button1Text: 'Settle Contest',
      button2Text: 'View/Edit Picks',
    ),
    ContestModel(
      name: 'Champions League Semi Finals',
      entryText: 'Entry 2 of 3',
      winsText: 'Highest Bankroll Wins',
      modeText: 'Free-To-Play',
      availableText: 'Available \$50,000',
      endsText: 'Ends 4/16',
      button1Text: 'Make Pick(s)',
      button2Text: 'View/Edit Picks',
    ),
    ContestModel(
      name: 'Hollywood Contest',
      entryText: 'Entry 1 of 3',
      winsText: 'Most Correct Answers Wins',
      modeText: 'Private',
      availableText: '12 of 12 Picks Made',
      endsText: 'Ends 4/16',
      button1Text: 'Settle Contest',
      button2Text: 'View/Edit Picks',
    ),
    ContestModel(
      name: 'Champions League Semi Finals',
      entryText: 'Entry 2 of 3',
      winsText: 'Highest Bankroll Wins',
      modeText: 'Free-To-Play',
      availableText: 'Available \$50,000',
      endsText: 'Ends 4/16',
      button1Text: 'Make Pick(s)',
      button2Text: 'View/Edit Picks',
    ),
    ContestModel(
      name: 'Hollywood Contest',
      entryText: 'Entry 1 of 3',
      winsText: 'Most Correct Answers Wins',
      modeText: 'Private',
      availableText: '12 of 12 Picks Made',
      endsText: 'Ends 4/16',
      button1Text: 'Settle Contest',
      button2Text: 'View/Edit Picks',
    ),
    ContestModel(
      name: 'Champions League Semi Finals',
      entryText: 'Entry 2 of 3',
      winsText: 'Highest Bankroll Wins',
      modeText: 'Free-To-Play',
      availableText: 'Available \$50,000',
      endsText: 'Ends 4/16',
      button1Text: 'Make Pick(s)',
      button2Text: 'View/Edit Picks',
    ),
    ContestModel(
      name: 'Hollywood Contest',
      entryText: 'Entry 1 of 3',
      winsText: 'Most Correct Answers Wins',
      modeText: 'Private',
      availableText: '12 of 12 Picks Made',
      endsText: 'Ends 4/16',
      button1Text: 'Settle Contest',
      button2Text: 'View/Edit Picks',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade500,
      body: Column(
        children: [
          Container(
            color: Colors.grey.shade100,
            padding: EdgeInsets.all(12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'CONTESTS',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Row(
                  children: [
                    Text(
                      'FILTER',
                      style: TextStyle(
                        color: Colors.cyan,
                        fontSize: 16,
                      ),
                    ),
                    Icon(
                      Icons.keyboard_arrow_down,
                      color: Colors.cyan,
                      size: 20,
                    )
                  ],
                )
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: contests.length,
              itemBuilder: (context, index) => ContestCard(
                contests[index],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
