package com.example.pinakin_infotech

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
